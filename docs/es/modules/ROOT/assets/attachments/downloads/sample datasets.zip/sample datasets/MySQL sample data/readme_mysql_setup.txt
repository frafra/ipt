Instructions on how to set up a database called portal_test, with a single table
called raw_occurrence_record, populated with several thousand occurrence records.
Sample connection parameters to be used to connect from your IPT to the database
are also shown below.

# create database 
mysql>create database portal_test DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;

# create and populate table from script
$ mysql -u root -p -Dportal_test < $DIR/portal.sql

# connect to MySQL externally

Host name: 192.168.100.5 (replace with your own, or just localhost, 127.0.0.1)
Database name: portal_test
Database user: root
Database password: (replace with your own)
Sample SQL statement: select * from raw_occurrence_record limit 10;
